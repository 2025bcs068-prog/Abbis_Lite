# ABBIS Lite — Blood Network Intelligence

**Terumo BCT Africa Hackathon 2026 · Challenge area: Redistribution**

ABBIS Lite helps blood-service coordinators identify a likely shortage at one facility while suitable stock may be approaching expiry elsewhere. It inspects imperfect records, estimates short-horizon demand, checks safe stock and transport constraints, and presents explainable redistribution opportunities for human review.

> **Data notice:** The organisers' one-year starter dataset is synthetic and modelled on Kenya. It contains no real donor, patient or facility records. Findings must not be presented as real-world hospital performance.

## What makes ABBIS Lite different

1. **Data quality before recommendations.** Flags duplicate-like donor identities, missing blood groups, unknown emergency groups, unresolved facility labels, unconfirmed transfers, sensor glitches and donor interval anomalies.
2. **A defensible stock view.** Reconciles the final daily-stock snapshot against the unit ledger. On 31 October 2026, both report 8,666 units (difference: zero).
3. **Expiry-aware redistribution.** Finds exact blood-group and component matches from regional/satellite centres to hospitals with a projected shortfall. Excludes temperature-exposed units, checks route time and shelf life on arrival, checks destination cold-chain readiness and retains a source dispatch reserve.
4. **Honest forecasting.** Compares a 7-day mean baseline, 28-day moving average and weekly seasonal-naive forecast using rolling-origin backtesting. If even the best candidate has WAPE above 0.50, ABBIS falls back to the transparent baseline.
5. **Human control.** A reviewer can Accept, Change or Reject a proposal. A reason is required for Change or Reject. Decisions are stored in a local SQLite audit log; no stock is automatically dispatched.
6. **Low-connectivity support.** Generates short SMS drafts (maximum 160 characters) for staff to review and send.

## What the dataset revealed

- 47 facilities, 43,363 donor records, 49,426 blood-unit records, 17,430 hospital requests and 35,181 transfers.
- 87.1% of requests were fully fulfilled.
- 8,620 of 37,147 RBC and whole-blood records were expired or discarded after temperature exposure (23.2%).
- 452 additional donor rows share a composite identity; 506 donor records have no blood group.
- 1,046 transfers have no receipt confirmation; 55 sensor readings are known sentinel glitches.
- 4,607 valid temperature readings are outside 2–6°C and require cold-chain investigation.
- The conservative 7-day redistribution matcher identifies 18 candidate opportunities in the supplied snapshot.

See [`docs/DATA_QUALITY_FINDINGS.md`](docs/DATA_QUALITY_FINDINGS.md) for the full profile and a worked recommendation.

## Forecast evaluation example

Default review scenario: **HSP-018 · A+ · RBC**, evaluated with eight rolling-origin folds and a seven-day horizon.

| Method | WAPE | MAE |
|---|---:|---:|
| 7-day mean baseline | 1.016 | 1.923 |
| 28-day moving average | 0.953 | 1.804 |
| Weekly seasonal naive | 1.189 | 2.250 |

The 28-day moving average improves WAPE by about 6.2% against the baseline in this example, but its WAPE is still above the 0.50 confidence gate. ABBIS therefore **does not present it as reliable** and falls back to the 7-day mean baseline. This is an intentional safeguard, not a failed demo.

## Run locally

Requires Python 3.11 or newer.

```bash
chmod +x run.sh
./run.sh
```

The script creates a virtual environment, installs dependencies, profiles the raw data, runs the forecast comparison and launches Streamlit. Open the local URL printed in the terminal (normally **http://localhost:8501**).

Manual setup:

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\\Scripts\\activate
python -m pip install -r requirements.txt
python -m scripts.prepare_data
python -m scripts.evaluate_forecast
streamlit run app.py
```

## Main screens

- **Overview:** network KPIs, demand/fulfilment trend, stock by blood group, shortage facilities and snapshot reconciliation.
- **Data quality:** measured defects, safe transformations and raw-data preservation policy.
- **Redistribution planner:** 7-day candidate moves with source, destination, group, component, demand, safe stock, reserve, expiry, route and cold-chain checks; Accept / Change / Reject controls; SMS drafts.
- **Demand forecast:** model comparison, rolling-origin WAPE/MAE, forecast and uncertainty interval, fallback indicator.
- **Decision audit:** local reviewer, decision, quantity, reason and timestamp.
- **About ABBIS:** problem, workflow, safety boundaries and limitations.

## Architecture

```mermaid
flowchart TD
  A[Official synthetic CSVs] --> B[Validation and safe analytical views]
  B --> C[Stock reconciliation and demand history]
  C --> D[Expiry-aware redistribution matcher]
  C --> E[Forecasts vs 7-day baseline]
  D --> F{Human review}
  F -->|Accept| G[Local audit record]
  F -->|Change| G
  F -->|Reject| G
  H[SMS draft] --> F
```

## Data handling and safety

- Raw files in `data/raw/` are never modified.
- `python -m scripts.prepare_data` writes explicit analytical copies (including unit eligibility after screening checks) and a report under `data/processed/`.
- Facility IDs are canonical; raw facility labels are preserved for review.
- Unknown blood groups are treated as missing, not guessed.
- Temperature sentinel values (-99, 99.9 and 0.0) are masked in the analytical view; raw readings remain intact.
- Transfers without `received_at` remain pending confirmation.
- The matcher only considers exact blood-group and component pairs, explicitly non-reactive tested units, in-stock non-temperature-exposed units, source centres with adequate cold-chain readiness, destinations with fridge backup or at least 90% grid reliability, routes of at most 12 typical hours and at least two days of shelf life on arrival.
- No recommendation is a clinical compatibility decision or dispatch instruction. The local audit is a demo log, not a tamper-proof authenticated service.

## What works now / what is not production-ready

**Working:** data profiling, safe analytical views, dashboard, snapshot reconciliation, rule-based redistribution opportunities, rolling forecast comparison, baseline fallback, SMS drafts, Accept/Change/Reject review and local audit trail.

**Not implemented:** live blood-service integrations, actual dispatch, clinical authorization, authenticated multi-user roles, tamper-proof audit, cross-device offline synchronization, SMS sending, or production-grade cold-chain release controls. Acceptance records a decision; it does not move physical stock.

## Tests

```bash
python -m pytest -q
```

The tests cover measured dataset checks, stock reconciliation, safe redistribution constraints, forecast fallback and one-decision-per-recommendation audit behaviour.

## Demo video

A timed script for a video under three minutes is in [`docs/DEMO_VIDEO_SCRIPT.md`](docs/DEMO_VIDEO_SCRIPT.md). Record the actual app in Streamlit; do not narrate unverified savings or claim a transfer was dispatched.

## AI tools

- **ChatGPT:** data profiling, code drafting, debugging, test design and documentation.
- **Claude:** initial project planning and design discussion.
- **Gemini:** additional assistance used by the team (describe the specific tasks in the final team submission).

## Team

| Name | Role | Country |
|---|---|---|
| Biyimbwa Elijah Simwogerere | Team lead, backend, architecture | Uganda |
| Kissa Keith Ndiema | Backend, AI/data | Uganda |
| Okori Sadrach | AI/data | Uganda |
| Tusiime Betty | Frontend | Uganda |
| Kisembo Stephen | AI/data, frontend | Uganda |

## Disclaimer

ABBIS Lite is a hackathon prototype for demonstration and evaluation only. It is not a certified blood-bank information system and must not be used to authorize transfusion or dispatch blood.
